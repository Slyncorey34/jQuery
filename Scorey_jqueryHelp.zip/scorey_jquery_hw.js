$(document).ready(
	function(){

	$("#verbz").on("click",
	function(e) {
	// 	$(".greeting").css("background-color", "lightgreen");
		// var source = $('#verbz').attr('src');
		// console.log(source);
		e.preventDefault();
		var $image = $("#chosen-image");
		$image.attr("src", $(this).attr("src")); 
	$(".backdrop").show(1000,function() { 
	// $("#this-image").attr("src","ab.jpg");

	$(".backdrop").on("click",
	function() {
	$(".backdrop").hide();

	});
	});
});  
});